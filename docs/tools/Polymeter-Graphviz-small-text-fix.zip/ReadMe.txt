This registry file fixes undersized graph text in the Polymeter application.
The issue occurs when the Windows system text size is set greater than 100%,
as may be the case when using a high-resolution monitor.

Double-click Polymeter-Graphviz-small-text-fix.reg, or select it and press 
the Enter key. When prompted "Are you sure you want to continue?" click the 
"Yes" button to proceed with the fix.

Polymeter uses Graphviz to generate graphs, and displays the resulting SVG
files via Microsoft's IWebBrowser2 control. The text is undersized because
IWebBrowser2 is not DPI-aware by default. This registry fix solves the issue
by making IWebBrowser2 DPI-aware, for Polymeter.exe only.








